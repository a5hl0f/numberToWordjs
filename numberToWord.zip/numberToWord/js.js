



let cont= document.querySelector('#q');
let input=document.querySelector('input');
let output=document.querySelector('h1');

cont.addEventListener('click',()=>{output.innerText=numberToWord.toWords(input.value);});